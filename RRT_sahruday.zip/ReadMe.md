
Dependencies : ROS noetic

Put the rrt folder in catkin_ws and do catkin_make

run the sandeer_sahruday_MultiRRT python file which will generate an output file.

Copy the paths of the final path txt 1,2,3 files in the output file and paste in tb_0,tb_1,tb_2 files in the rrt ros package respectively.

run Roslaunch rrt RRT.launch

Simulation begins.

The robots does not follow the path generated in the text file. Tried different approaches but failed.

